exports.themeLocation = './realme/';
exports.urlToPreview = 'http://localhost/realme';
